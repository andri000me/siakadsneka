<?php
class Link_m extends MY_Model
{
	protected $_table_name = 'link';
	protected $_order_by = 'id';
	public $rules = array(
			'link_judul' => array(
					'field' => 'link_judul',
					'label' => 'Judul Link',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'link_url' => array(
					'field' => 'link_url',
					'label' => 'Alamat Url Link',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			
	
	);

	public function get_new ()
	{
		$linkweb = new stdClass();
		$linkweb->link_judul = '';
		$linkweb->link_url = '';
		
		
		return $linkweb;
	}

	
}