<?php
class Config_m extends MY_Model
{
	protected $_table_name = 'web_config';
	protected $_order_by = 'id';
	public $rules = array(
			'site_judul' => array(
					'field' => 'site_judul',
					'label' => 'Judul Site',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'site_keyword' => array(
					'field' => 'site_keyword',
					'label' => 'Keyword Site',
					'rules' => 'trim|required|max_length[255]|xss_clean'
			),
			'site_description' => array(
					'field' => 'site_description',
					'label' => 'Description Site',
					'rules' => 'trim|required|max_length[255]|xss_clean'
			),
			'site_author' => array(
					'field' => 'site_author',
					'label' => 'Author Site',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'site_url' => array(
					'field' => 'site_url',
					'label' => 'Url Site',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'site_reason' => array(
					'field' => 'site_reason',
					'label' => 'Reason Site',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			
	
	
	);

	public function get_new ()
	{
		$configweb = new stdClass();
		$configweb->site_judul = '';
		$configweb->site_keyword = '';
		$configweb->site_description = '';
		$configweb->site_author = '';
		$configweb->site_url = '';
		$configweb->site_reason = '';

		return $configweb;
	}
	public function set_cmsconfig(){
		$this->db->where('id', 1);
	}
	
}