<?php
class Kritik_saran_m extends MY_Model {
	protected $_table_name = 'kritik_saran';
	protected $_order_by = 'id desc';
	public $rules = array (
			'nama' => array (
					'field' => 'nama',
					'label' => 'Nama',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			),
			'email' => array (
					'field' => 'email',
					'label' => 'Email',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			),
			'judul' => array (
					'field' => 'judul',
					'label' => 'Judul',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			),
			'pesan' => array (
					'field' => 'pesan',
					'label' => 'Pesan',
					'rules' => 'trim|required|xss_clean' 
			),
			'waktu' => array (
					'field' => 'waktu',
					'label' => 'Waktu',
					'rules' => 'trim|max_length[100]||xss_clean'
			),
			'baca' => array (
					'field' => 'baca',
					'label' => 'baca',
					'rules' => 'trim|max_length[100]||xss_clean'
			),
			'g-recaptcha-response' => array(
					'field' => 'g-recaptcha-response',
					'label' => 'Captcha',
					'rules' => 'trim|required|callback_cek_captcha'
			),
	);
	public function get_new() {
		$inventaris = new stdClass ();
		$inventaris->nama = '';
		$inventaris->email = '';
		$inventaris->judul = '';
		$inventaris->pesan = '';
		$inventaris->waktu = '';
		$inventaris->baca = '';
		return $inventaris;
	}
	public function set_kritiksaranbaru(){
		$this->db->where('baca', NULL);
		//$this->db->limit(10);
	}
	
	public function get_data_pesan ()
	{
		// Fetch pages without parents
		$this->db->select('id');
	
		$pesan = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($pesan )) {
			foreach ($pesan as $pesans) {
				$array[$pesans->id] = $pesans->id;
			}
		}
	
		return $array;
	}
}