<?php
class Cosmide_setting_m extends MY_Model
{
	protected $_table_name = 'cosmide_setting';
	protected $_order_by = 'id desc';

	public $rules = array(
			'file_studikasus' => array(
					'field' => 'file_studikasus',
					'label' => 'File Studi Kasus',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'status_studikasus' => array(
					'field' => 'status_studikasus',
					'label' => 'Status Studi Kasus',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'video_judul' => array(
					'field' => 'video_judul',
					'label' => 'Video Judul',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'video_deskripsi' => array(
					'field' => 'video_deskripsi',
					'label' => 'Video Deskripsi',
					'rules' => 'trim|required|xss_clean'
			),
			'video_status' => array(
					'field' => 'video_status',
					'label' => 'Video Status',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'date_register' => array(
					'field' => 'date_register',
					'label' => 'Date Register',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'date_report' => array(
					'field' => 'date_report',
					'label' => 'Date Report',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			
	
	
	);

	public function get_new ()
	{
		$cosmidesetting = new stdClass();
		$cosmidesetting->file_studikasus = '';
		$cosmidesetting->status_studikasus = '';
		$cosmidesetting->video_judul = '';
		$cosmidesetting->video_url = '';
		$cosmidesetting->video_deskripsi = '';
		$cosmidesetting->video_status = '';
		$cosmidesetting->date_register = '';
		$cosmidesetting->date_report = '';

		return $cosmidesetting;
	}

		public function set_cosmide_setting() {
		$this->db->where('id', 1);
	}

	public function get_datatanggal()
	{
		// Fetch pages without parents
		$this->db->select('id, date_report');
		$this->db->where('id', 1);
		$datatanggals = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($datatanggals )) {
			foreach ($datatanggals  as $datatanggal) {
				$array['date_report']=$datatanggal->date_report;
			}
		}
	
		return $array;
	}

	public function get_datatanggal2()
	{
		// Fetch pages without parents
		$this->db->select('id, date_register');
		$this->db->where('id', 1);
		$datatanggals = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($datatanggals )) {
			foreach ($datatanggals  as $datatanggal) {
				$array['date_register']=$datatanggal->date_register;
			}
		}
	
		return $array;
	}

	public function get_datavideo()
	{
		// Fetch pages without parents
		$this->db->select('id, file_studikasus, status_studikasus, video_judul, video_url, video_deskripsi, video_status');
		$this->db->where('id', 1);
		$datavideos = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($datavideos )) {
			foreach ($datavideos  as $datavideo) {
				$array['file_studikasus']=$datavideo->file_studikasus;
				$array['status_studikasus']=$datavideo->status_studikasus;
				$array['video_judul']=$datavideo->video_judul;
				$array['video_judul']=$datavideo->video_judul;
				$array['video_url']=$datavideo->video_url;
				$array['video_deskripsi']=$datavideo->video_deskripsi;
				$array['video_status']=$datavideo->video_status;
				

			}
		}
	
		return $array;
	}



		public function set_cosmide_setting2() {
		$this->db->where('id', 1);
	}
	
	
}