<?php
class Gallery_M extends MY_Model
{
	
	protected $_table_name = 'gallery';
	protected $_order_by = 'priority';
	public $rules = array(
		'url' => array(
			'field' => 'url', 
			'label' => 'Alamat Url', 
			'rules' => 'trim|required|max_length[100]|xss_clean'
		), 
		
	);
	
	public function get_new(){
		$gallery = new stdClass();
		$gallery->url = '';
		return $gallery;
	}

}