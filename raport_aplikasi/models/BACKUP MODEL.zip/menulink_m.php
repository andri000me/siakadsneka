<?php
class Menulink_m extends MY_Model
{
	protected $_table_name = 'menu_link';
	protected $_order_by = 'id desc';
	public $rules = array(
			'link_judul' => array(
					'field' => 'link_judul',
					'label' => 'Judul Link',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'link_url' => array(
					'field' => 'link_url',
					'label' => 'Alamat Url Link',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			
	
	);

	public function get_new ()
	{
		$menulink = new stdClass();
		$menulink->link_judul = '';
		$menulink->link_url = '';
		
		
		return $menulink;
	}

	
	
}