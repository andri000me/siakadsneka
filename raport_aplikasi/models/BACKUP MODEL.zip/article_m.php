<?php
class Article_m extends MY_Model
{
	protected $_table_name = 'articles';
	protected $_order_by = 'pubdate desc, id desc';
	protected $_timestamps = TRUE;
	public $rules = array (
			'pubdate' => array (
					'field' => 'pubdate',
					'label' => 'Publication date',
					'rules' => 'trim|required|exact_length[10]|xss_clean' 
			),
			'title' => array (
					'field' => 'title',
					'label' => 'Title',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			),
			'slug' => array (
					'field' => 'slug',
					'label' => 'Slug',
					'rules' => 'trim|required|max_length[100]|url_title|xss_clean' 
			),
			'body' => array (
					'field' => 'body',
					'label' => 'Body',
					'rules' => 'trim|required' 
			),
			'category' => array (
					'field' => 'category',
					'label' => 'Category',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			),
			'author' => array (
					'field' => 'author',
					'label' => 'Author',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			),

			'tags' => array (
					'field' => 'tags',
					'label' => 'Tags',
					'rules' => 'trim|max_length[100]|xss_clean' 
			),
			'status' => array (
					'field' => 'status',
					'label' => 'Publish Article',
					'rules' => 'trim|required|max_length[100]|xss_clean' 
			) 
	);

	public function get_new ()
	{
		$article = new stdClass();
		$article->title = '';
		$article->slug = '';
		$article->body = '';
		$article->category = '';
		$article->keywords = '';
		$article->description = '';
		$article->image = '';
		$article->author = '';
		$article->tags = '';
		$article->status = '';
		$article->pubdate = date('Y-m-d');
		return $article;
	}
	
	public function set_published(){
		$this->db->where('pubdate <=', date('Y-m-d'));
		
	}
	
	public function set_news(){
		$this->db->where('pubdate <=', date('Y-m-d'));
		$this->db->where('status', 'yes');
	}
	public function set_berita(){
		$this->db->where('pubdate <=', date('Y-m-d'));
		$this->db->where('status', 'yes');
		//$this->db->where('category', 'Berita');
		$this->db->limit(10);
	}

	public function set_beritabaru(){
		$this->db->where('pubdate <=', date('Y-m-d'));
		$this->db->where('status', 'yes');
		//$this->db->where('category', 'Berita');
		$this->db->limit(2);
	}

	public function set_beritabaru2(){
		$this->db->where('pubdate <=', date('Y-m-d'));
		$this->db->where('status', 'yes');

		//$this->db->where('category', 'Berita');
		$this->db->limit(1);
		$this->db->order_by('id asc');
	}
	
	
	public function set_category(){
		$this->db->where('pubdate <=', date('Y-m-d'));
		$this->db->where('status', 'yes');
		$this->db->where('category', $this->uri->segment(2));
		
		//$this->db->limit(10);
	}

	public function set_sebelum(){
		$this->db->where('id <', $this->uri->segment(2));
		$this->db->limit(1);
		$this->db->order_by('id desc');
	}

	public function set_setelah(){
		$this->db->where('id >', $this->uri->segment(2));
		$this->db->limit(1);
		$this->db->order_by('id asc');
	}

	public function get_recent($limit = 3){
		
		// Fetch a limited number of recent articles
		$limit = (int) $limit;
		$this->set_published();
		$this->db->limit($limit);
		return parent::get();
	}
	
	

	
	
}