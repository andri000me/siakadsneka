<?php
class Kota_indonesia_m extends MY_Model
{		

	protected $_table_name = 'master_city';
	protected $_order_by = 'city_id asc';
	
   
    
    public function get_data_kota()
    {
    	// Fetch pages without parents
    	$this->db->select('city_id, city_name');
	
		$namakotas = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($namakotas )) {
			foreach ($namakotas  as $namakota) {
				$array[''] = 'Pilih Kota / Kabupaten';
				$array[$namakota->city_id] = $namakota->city_name;
			}
		}
	
		return $array;
    }
    
    
   

}
?>