<?php
class Provinsi_indonesia_m extends MY_Model
{		

	protected $_table_name = 'master_state';
	protected $_order_by = 'state_id asc';
	
    function get_state($id = NULL){
        $this->db->order_by("state_id", "ASC");
        $this->db->where("state_country_id", 'indonesia');
        return $this->db->get("master_state");        
    }
    
    function get_city() {
        $this->db->order_by("city_id", "ASC");
        $this->db->where("city_id", $id);
        return $this->db->get("master_city");        
    }

     
    function get_kotaindex($id) {
    	$this->db->order_by("city_id", "ASC");
    	$this->db->where("city_id", $id);
    	$query = $this->db->get("master_city");
    	if ($query->num_rows() > 0) return $query->result();
    }


    function get_provinsiindex($id) {
        $this->db->order_by("state_id", "ASC");
        $this->db->where("state_id", $id);
        $query = $this->db->get("master_state");
        if ($query->num_rows() > 0) return $query->result();
    }
	
    function get_city_by_state($id) {
        $this->db->order_by("city_name", "ASC");
        $this->db->where("city_state_id", $id);
        $query = $this->db->get("master_city");
        if ($query->num_rows() > 0) return $query->result();              
    }
    
    public function get_data_provinsi()
    {
    	// Fetch pages without parents
    	$this->db->select('state_id, state_name');
	
		$namaprovinsis = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($namaprovinsis )) {
			foreach ($namaprovinsis  as $namaprovinsi) {
				$array[''] = 'Pilih Kota / Kabupaten';
				$array[$namaprovinsi->state_id] = $namaprovinsi->state_name;
			}
		}
	
		return $array;
    }

   
    
    
  

}
?>