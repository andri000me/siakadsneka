<?php
class Peserta_cosmide_m extends MY_Model
{   
	protected $_table_name = 'peserta_cosmide';
	protected $_order_by = 'id desc';
	protected $_timestamps = TRUE;
	public $rules_login = array(
		'email' => array(
			'field' => 'email', 
			'label' => 'Username/Email', 
			'rules' => 'trim|required|valid_email|valid_emails|xss_clean'
		), 
		'password' => array(
			'field' => 'password', 
			'label' => 'Password', 
			'rules' => 'trim|required'
		),
		'g-recaptcha-response' => array(
					'field' => 'g-recaptcha-response',
					'label' => 'Captcha',
					'rules' => 'trim|callback_cek_captcha'
			),
	);

	public $rules_mendaftar = array(
		'email' => array(
			'field' => 'email', 
			'label' => 'Username/Email', 
			'rules' => 'trim|required|valid_email|valid_emails|callback__unique_email'
		), 
		'password' => array(
			'field' => 'password', 
			'label' => 'Password', 
			'rules' => 'trim|required|min_length[8]'
		),
		'password_confirm' => array(
					'field' => 'password_confirm',
					'label' => 'Confirm password',
					'rules' => 'trim|required|matches[password]'
			),
		'g-recaptcha-response' => array(
					'field' => 'g-recaptcha-response',
					'label' => 'Captcha',
					'rules' => 'trim|required|callback_cek_captcha'
			),
		'reset_password' => array(
					'field' => 'reset_password',
					'label' => 'Reset Password',
					'rules' => 'trim|xss_clean'
		),
		'code_confirm' => array(
					'field' => 'code_confirm',
					'label' => 'Code Confirmasi',
					'rules' => 'trim|xss_clean'
		),
	);

	public $rules_newpassword = array(
		
		'password' => array(
			'field' => 'password', 
			'label' => 'Password', 
			'rules' => 'trim|required|min_length[8]'
		),
		'password_confirm' => array(
					'field' => 'password_confirm',
					'label' => 'Confirm password',
					'rules' => 'trim|required|matches[password]'
			),
	);

	public $rules_kirimaktivasi = array(
		'email' => array(
			'field' => 'email', 
			'label' => 'Username/Email', 
			'rules' => 'trim|required|valid_email|valid_emails'
		),
		'code_confirm' => array(
					'field' => 'code_confirm',
					'label' => 'Code Confirmasi',
					'rules' => 'trim|xss_clean'
		), 
	);


	public $rules_resetpassword = array(
		'email' => array(
			'field' => 'email', 
			'label' => 'Username/Email', 
			'rules' => 'trim|required|valid_email|valid_emails'
		), 
		'reset_password' => array(
					'field' => 'reset_password',
					'label' => 'Reset Password',
					'rules' => 'trim|xss_clean'
		),
	);

	public $rules_configteam = array(
		'nama_team' => array(
			'field' => 'nama_team', 
			'label' => 'Nama Team', 
			'rules' => 'trim|required|max_length[100]|callback__unique_nama_team'
		), 
		'nama_univ' => array(
			'field' => 'nama_univ', 
			'label' => 'Nama Universitas', 
			'rules' => 'trim|required|max_length[100]|xss_clean'
		),
	);

	public $rules_buktipembayaran = array(
		'file_bukti_pembayaran' => array(
					'field' => 'file_bukti_pembayaran',
					'label' => 'File Bukti Pembayaran',
					'rules' => 'trim|max_length[500]|xss_clean'
			),
		'tanggal_uploadpembayaran' => array(
					'field' => 'tanggal_uploadpembayaran',
					'label' => 'Tanggal Upload Pembayaran',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
	);

	public $rules_gantipassword = array(
		'password' => array(
			'field' => 'password', 
			'label' => 'Password Baru', 
			'rules' => 'trim|required|min_length[8]'
		),
		'password_confirm' => array(
					'field' => 'password_confirm',
					'label' => 'Confirm Password Baru',
					'rules' => 'trim|required|matches[password]'
			),
	);



	public $rules_uploadpaper = array(
		'file_upload_paper' => array(
					'field' => 'file_upload_paper',
					'label' => 'File Upload Paper',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
		'tanggal_uploadpaper' => array(
					'field' => 'tanggal_uploadpaper',
					'label' => 'Tanggal Upload Paper',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
	);



	public $rules_editbiodata = array(
			'ketua_namalengkap' => array(
					'field' => 'ketua_namalengkap',
					'label' => 'Nama Lengkap Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_email' => array(
					'field' => 'ketua_email',
					'label' => 'Email Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_tempatlahir' => array(
					'field' => 'ketua_tempatlahir',
					'label' => 'Tempat Lahir Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_tanggallahir' => array(
					'field' => 'ketua_tanggallahir',
					'label' => 'Tanggal Lahir Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_handphone' => array(
					'field' => 'ketua_handphone',
					'label' => 'No Handphone Ketua',
					'rules' => 'trim|required|max_length[15]|xss_clean'
			),
			'ketua_jenis_kelamin' => array(
					'field' => 'ketua_jeniskelamin',
					'label' => 'Jenis Kelamin Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_alamat' => array(
					'field' => 'ketua_alamat',
					'label' => 'Alamat Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_foto' => array(
					'field' => 'ketua_foto',
					'label' => 'Foto Ketua',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'ketua_ktm' => array(
					'field' => 'ketua_ktm',
					'label' => 'KTM Ketua 2',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota1_namalengkap' => array(
					'field' => 'anggota1_namalengkap',
					'label' => 'Nama Lengkap anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_email' => array(
					'field' => 'anggota1_email',
					'label' => 'Email anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_tempatlahir' => array(
					'field' => 'anggota1_tempatlahir',
					'label' => 'Tempat Lahir anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_tanggallahir' => array(
					'field' => 'anggota1_tanggallahir',
					'label' => 'Tanggal Lahir anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_handphone' => array(
					'field' => 'anggota1_handphone',
					'label' => 'No Handphone anggota1',
					'rules' => 'trim|required|max_length[15]|xss_clean'
			),
			'anggota1_jenis_kelamin' => array(
					'field' => 'anggota1_jeniskelamin',
					'label' => 'Jenis Kelamin anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_alamat' => array(
					'field' => 'anggota1_alamat',
					'label' => 'Alamat anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_foto' => array(
					'field' => 'anggota1_foto',
					'label' => 'Foto anggota1',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota1_ktm' => array(
					'field' => 'anggota1_ktm',
					'label' => 'KTM anggota1',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota2_namalengkap' => array(
					'field' => 'anggota2_namalengkap',
					'label' => 'Nama Lengkap anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_email' => array(
					'field' => 'anggota2_email',
					'label' => 'Email anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_tempatlahir' => array(
					'field' => 'anggota2_tempatlahir',
					'label' => 'Tempat Lahir anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_tanggallahir' => array(
					'field' => 'anggota2_tanggallahir',
					'label' => 'Tanggal Lahir anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_handphone' => array(
					'field' => 'anggota2_handphone',
					'label' => 'No Handphone anggota2',
					'rules' => 'trim|required|max_length[15]|xss_clean'
			),
			'anggota2_jenis_kelamin' => array(
					'field' => 'anggota2_jeniskelamin',
					'label' => 'Jenis Kelamin anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_alamat' => array(
					'field' => 'anggota2_alamat',
					'label' => 'Alamat anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_foto' => array(
					'field' => 'anggota2_foto',
					'label' => 'Foto anggota2',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota2_ktm' => array(
					'field' => 'anggota2_ktm',
					'label' => 'KTM anggota2',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			
	);
public $rules_adminedit = array(
	
			'email' => array(
			'field' => 'email', 
			'label' => 'Username/Email', 
			'rules' => 'trim|required|valid_email|valid_emails|callback__unique_email'
			), 
			'password' => array(
				'field' => 'password', 
				'label' => 'Password', 
				'rules' => 'trim|required|min_length[8]'
			),
			'password_confirm' => array(
						'field' => 'password_confirm',
						'label' => 'Confirm password',
						'rules' => 'trim|required|matches[password]'
				),
			'ketua_namalengkap' => array(
					'field' => 'ketua_namalengkap',
					'label' => 'Nama Lengkap Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_email' => array(
					'field' => 'ketua_email',
					'label' => 'Email Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_tempatlahir' => array(
					'field' => 'ketua_tempatlahir',
					'label' => 'Tempat Lahir Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_tanggallahir' => array(
					'field' => 'ketua_tanggallahir',
					'label' => 'Tanggal Lahir Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_handphone' => array(
					'field' => 'ketua_handphone',
					'label' => 'No Handphone Ketua',
					'rules' => 'trim|required|max_length[15]|xss_clean'
			),
			'ketua_jenis_kelamin' => array(
					'field' => 'ketua_jeniskelamin',
					'label' => 'Jenis Kelamin Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_alamat' => array(
					'field' => 'ketua_alamat',
					'label' => 'Alamat Ketua',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'ketua_foto' => array(
					'field' => 'ketua_foto',
					'label' => 'Foto Ketua',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'ketua_ktm' => array(
					'field' => 'ketua_ktm',
					'label' => 'KTM Ketua 2',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota1_namalengkap' => array(
					'field' => 'anggota1_namalengkap',
					'label' => 'Nama Lengkap anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_email' => array(
					'field' => 'anggota1_email',
					'label' => 'Email anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_tempatlahir' => array(
					'field' => 'anggota1_tempatlahir',
					'label' => 'Tempat Lahir anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_tanggallahir' => array(
					'field' => 'anggota1_tanggallahir',
					'label' => 'Tanggal Lahir anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_handphone' => array(
					'field' => 'anggota1_handphone',
					'label' => 'No Handphone anggota1',
					'rules' => 'trim|required|max_length[15]|xss_clean'
			),
			'anggota1_jenis_kelamin' => array(
					'field' => 'anggota1_jeniskelamin',
					'label' => 'Jenis Kelamin anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_alamat' => array(
					'field' => 'anggota1_alamat',
					'label' => 'Alamat anggota1',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota1_foto' => array(
					'field' => 'anggota1_foto',
					'label' => 'Foto anggota1',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota1_ktm' => array(
					'field' => 'anggota1_ktm',
					'label' => 'KTM anggota1',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota2_namalengkap' => array(
					'field' => 'anggota2_namalengkap',
					'label' => 'Nama Lengkap anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_email' => array(
					'field' => 'anggota2_email',
					'label' => 'Email anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_tempatlahir' => array(
					'field' => 'anggota2_tempatlahir',
					'label' => 'Tempat Lahir anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_tanggallahir' => array(
					'field' => 'anggota2_tanggallahir',
					'label' => 'Tanggal Lahir anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_handphone' => array(
					'field' => 'anggota2_handphone',
					'label' => 'No Handphone anggota2',
					'rules' => 'trim|required|max_length[15]|xss_clean'
			),
			'anggota2_jenis_kelamin' => array(
					'field' => 'anggota2_jeniskelamin',
					'label' => 'Jenis Kelamin anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_alamat' => array(
					'field' => 'anggota2_alamat',
					'label' => 'Alamat anggota2',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			'anggota2_foto' => array(
					'field' => 'anggota2_foto',
					'label' => 'Foto anggota2',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			'anggota2_ktm' => array(
					'field' => 'anggota2_ktm',
					'label' => 'KTM anggota2',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
			
	);
	public function get_new ()
	{
		$pesertacosmide = new stdClass();
		$pesertacosmide->password = '';
		$pesertacosmide->email = '';
		$pesertacosmide->code_confirm = '';
		$pesertacosmide->confirmed = '';
		$pesertacosmide->reset_password = '';
		$pesertacosmide->nama_team = '';
		$pesertacosmide->nama_univ = '';
		$pesertacosmide->file_bukti_pembayaran = '';
		$pesertacosmide->status_pembayaran = '';
		$pesertacosmide->file_upload_paper = '';
		$pesertacosmide->ketua_namalengkap = '';
		$pesertacosmide->ketua_email = '';
		$pesertacosmide->ketua_tempatlahir = '';
		$pesertacosmide->ketua_tanggallahir = '';
		$pesertacosmide->ketua_handphone = '';
		$pesertacosmide->ketua_jeniskelamin = '';
		$pesertacosmide->ketua_alamat = '';
		$pesertacosmide->ketua_foto = '';
		$pesertacosmide->ketua_ktm = '';
		$pesertacosmide->anggota1_namalengkap = '';
		$pesertacosmide->anggota1_email = '';
		$pesertacosmide->anggota1_tempatlahir = '';
		$pesertacosmide->anggota1_tanggallahir = '';
		$pesertacosmide->anggota1_handphone = '';
		$pesertacosmide->anggota1_jeniskelamin = '';
		$pesertacosmide->anggota1_alamat = '';
		$pesertacosmide->anggota1_foto = '';
		$pesertacosmide->anggota1_ktm = '';
		$pesertacosmide->anggota2_namalengkap = '';
		$pesertacosmide->anggota2_email = '';
		$pesertacosmide->anggota2_tempatlahir = '';
		$pesertacosmide->anggota2_tanggallahir = '';
		$pesertacosmide->anggota2_handphone = '';
		$pesertacosmide->anggota2_jeniskelamin = '';
		$pesertacosmide->anggota2_alamat = '';
		$pesertacosmide->anggota2_foto = '';
		$pesertacosmide->anggota2_ktm = '';
		$pesertacosmide->tanggal_mendaftar = '';
		$pesertacosmide->tanggal_uploadpembayaran = '';
		$pesertacosmide->tanggal_verifikasipembayaran = '';
		$pesertacosmide->tanggal_uploadpaper = '';

		return $pesertacosmide;
	}

	function aktifkan($key)
	{
	 $this->load->database();
	 $data = array(
	 'confirmed' => 1
	 );

	 $this->db->where('code_confirm', $key);
	 $this->db->update('peserta_cosmide', $data);

	 return true;
	}

	public function get_datakey ()
	{
		// Fetch pages without parents
		$this->db->select('id, code_confirm');
	
		$datakeys = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($datakeys )) {
			foreach ($datakeys  as $datakey) {
				$array[$datakey->code_confirm] = $datakey->code_confirm;
			}
		}
	
		return $array;
	}


	public function get_datatoken ()
	{
		// Fetch pages without parents
		$this->db->select('id, reset_password');
	
		$resetpasswords = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($resetpasswords )) {
			foreach ($resetpasswords  as $resetpassword) {
				$array[$resetpassword->reset_password] = $resetpassword->reset_password;
			}
		}
	
		return $array;
	}


	public function set_resetbyemail()
	{
		$this->db->where('reset_password', $this->uri->segment(4));
		
	}



	public function get_dataemail()
	{
		// Fetch pages without parents
		$this->db->select('id, email');
	
		$emails = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($emails )) {
			foreach ($emails  as $email) {
				$array[$email->email] = $email->email;
			}
		}
	
		return $array;
	}

	public function set_emailverifikasi(){
		$this->db->where('code_confirm', $this->uri->segment(3));
	}
	
	
	public function get_data_semuauser()
	{
		// Fetch pages without parents
		$this->db->select('id, email');
		
		$semuausers = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($semuausers )) {
			foreach ($semuausers  as $semuauser) {
				$array[]=$semuauser->email;
			}
		}
	
		return $array;
	}
	
	
	public function get_data_aktifuser()
	{
		// Fetch pages without parents
		$this->db->select('id, email, confirmed');
		$this->db->where('confirmed', 1);
		$aktifusers = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($aktifusers )) {
			foreach ($aktifusers  as $aktifuser) {
				$array[]=$aktifuser->email;
			}
		}
	
		return $array;
	}

	public function get_data_notaktif()
	{
		// Fetch pages without parents
		$this->db->select('id, email, confirmed');
		$this->db->where('confirmed', NULL);

		$notaktifusers = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($notaktifusers )) {
			foreach ($notaktifusers  as $notaktifuser) {
				$array[]=$notaktifuser->email;
			}
		}
	
		return $array;
	}

		public function get_data_sudahbayar()
	{
		// Fetch pages without parents
		$this->db->select('id, email, status_pembayaran');
		$this->db->where('status_pembayaran', 1);
		$sudahbayars = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($sudahbayars )) {
			foreach ($sudahbayars  as $sudahbayar) {
				$array[]=$sudahbayar->email;
			}
		}
	
		return $array;
	}

	public function get_data_belumbayar()
	{
		// Fetch pages without parents
		$this->db->select('id, email, status_pembayaran');
		$this->db->where('status_pembayaran', 0);
		$belumbayars = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($belumbayars )) {
			foreach ($belumbayars  as $belumbayar) {
				$array[]=$belumbayar->email;
			}
		}
	
		return $array;
	}
	
	
	public function get_data_pekerja ()
	{
		// Fetch pages without parents
		$this->db->select('id');
	
		$pekerjas = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($pekerjas )) {
			foreach ($pekerjas  as $pekerja) {
				$array[$pekerja->id] = $pekerja->id;
			}
		}
	
		return $array;
	}

	


	public function login ()
	{
		$user = $this->get_by(array(
			'email' => $this->input->post('email'),
			'password' => $this->hash($this->input->post('password')),
		), TRUE);
		
		if (count($user)) {
			// Log in user
			$data = array(
				'email' => $user->email,
				'password' => $user->password,
				'confirmed' => $user->confirmed,
				'nama_univ' => $user->nama_univ,
				'nama_team' => $user->nama_team,
				'file_bukti_pembayaran' => $user->file_bukti_pembayaran,
				'status_pembayaran' => $user->status_pembayaran,
				'file_upload_paper' => $user->file_upload_paper,
				'ketua_namalengkap' => $user->ketua_namalengkap,
				'ketua_email' => $user->ketua_email,
				'ketua_tempatlahir' => $user->ketua_tempatlahir,
				'ketua_tanggallahir' => $user->ketua_tanggallahir,
				'ketua_handphone' => $user->ketua_handphone,
				'ketua_jeniskelamin' => $user->ketua_jeniskelamin,
				'ketua_alamat' => $user->ketua_alamat,
				'ketua_foto' => $user->ketua_foto,
				'ketua_ktm' => $user->ketua_ktm,
				'anggota1_namalengkap' => $user->anggota1_namalengkap,
				'anggota1_email' => $user->anggota1_email,
				'anggota1_tempatlahir' => $user->anggota1_tempatlahir,
				'anggota1_tanggallahir' => $user->anggota1_tanggallahir,
				'anggota1_handphone' => $user->anggota1_handphone,
				'anggota1_jeniskelamin' => $user->anggota1_jeniskelamin,
				'anggota1_alamat' => $user->anggota1_alamat,
				'anggota1_foto' => $user->anggota1_foto,
				'anggota1_ktm' => $user->anggota1_ktm,
				'anggota2_namalengkap' => $user->anggota2_namalengkap,
				'anggota2_email' => $user->anggota2_email,
				'anggota2_tempatlahir' => $user->anggota2_tempatlahir,
				'anggota2_tanggallahir' => $user->anggota2_tanggallahir,
				'anggota2_handphone' => $user->anggota2_handphone,
				'anggota2_jeniskelamin' => $user->anggota2_jeniskelamin,
				'anggota2_alamat' => $user->anggota2_alamat,
				'anggota2_foto' => $user->anggota2_foto,
				'anggota2_ktm' => $user->anggota2_ktm,
				'id' => $user->id,
				
				'memberlogin' => TRUE,
			);
			$this->session->set_userdata($data);
		}
	}

	public function logout ()
	{
		$data = array(
				'email' => $this->session->userdata('email'),
				'password' => $this->session->userdata('password'),
				'confirmed' => $this->session->userdata('confirmed'),
				'nama_univ' => $this->session->userdata('nama_univ'),
				'nama_team' => $this->session->userdata('nama_team'),
				'id' => $this->session->userdata('id'),
				
				'memberlogin' => TRUE,
			);
			
		$this->session->unset_userdata($data);
	}

	public function memberlogin ()
	{
		return (bool) $this->session->userdata('memberlogin');
	}
	
	

	public function hash ($string)
	{
		return hash('sha512', $string . config_item('encryption_key'));
	}



	function ambil_data_member() {
	
		$hasil=$this->db->get('peserta_cosmide');
	
		$baris=$hasil->result();
	
		return $baris;
	
	}
}