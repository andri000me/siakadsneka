<?php
class Email_m extends MY_Model
{   
	protected $_table_name = 'email';
	protected $_order_by = 'id desc';
	protected $_timestamps = TRUE;
	public $rules = array(
			'tujuan' => array(
					'field' => 'tujuan',
					'label' => 'Tujuan',
					'rules' => 'trim|required|max_length[100]'
			),
			'option' => array(
					'field' => 'option',
					'label' => 'Option',
					'rules' => 'trim|max_length[255]'
			),
			'subject' => array(
					'field' => 'subject',
					'label' => 'Subject Pesan',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
			
			'isi' => array(
					'field' => 'isi',
					'label' => 'Isi Pesan',
					'rules' => 'trim|required'
			),
			'status' => array(
					'field' => 'status',
					'label' => 'Status',
					'rules' => 'trim|required|max_length[100]'
			),
			'date' => array(
					'field' => 'date',
					'label' => 'Date',
					'rules' => 'trim|required|max_length[100]|xss_clean'
			),
		
			
	);

	public function get_new ()
	{
		$email = new stdClass();
		$email->tujuan = '';
		$email->option = '';
		$email->subject = '';
		$email->isi = '';
		$email->status = '';
		$email->date = '';
		
		return $email;
	}

}