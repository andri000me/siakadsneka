<?php
class Category_m extends MY_Model
{
	protected $_table_name = 'category';
	protected $_order_by = 'id desc';
	public $rules = array(
		'category' => array(
			'field' => 'category', 
			'label' => 'Category Title', 
			'rules' => 'trim|required|max_length[100]|callback__unique_title|xss_clean'
		), 
			'slug' => array(
			'field' => 'slug',
			'label' => 'Slug',
			'rules' => 'trim|required|max_length[100]|url_title|callback__unique_slug|xss_clean'
			),
			
			'description' => array(
					'field' => 'description',
					'label' => 'Description',
					'rules' => 'trim|max_length[100]|xss_clean'
			),
	);

	public function get_new ()
	{
		$category = new stdClass();
		$category->category = '';
		$category->slug = '';
		$category->description = '';
		
		return $category;
	}
	
	public function set_judulcategory(){
		$this->db->where('slug', $this->uri->segment(2));
	}
	public function get_data_category()
	{
		// Fetch pages without parents
		$this->db->select('id, slug, category');
		
		$categorys = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($categorys )) {
			foreach ($categorys  as $category) {
				$array[$category->slug] = $category->category;
			}
		}
	
		return $array;
	}
	
	public function get_article_category ()
	{
		// Fetch pages without parents
		$this->db->select('id, slug');
	
		$categorys = parent::get();
	
		// Return key => value pair array
		$array = array();
		if (count($categorys )) {
			foreach ($categorys  as $category) {
				$array[$category->slug] = $category->slug;
			}
		}
	
		return $array;
	}
	
	

}