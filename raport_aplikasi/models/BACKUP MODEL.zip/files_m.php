<?php
class Files_m extends MY_Model {
	protected $_table_name = 'files';
	protected $_order_by = 'id';
	
	public function get_new ()
	{
		$uploadfiles = new stdClass();
		$uploadfiles->filename = '';
		$uploadfiles->title = '';
		$uploadfiles->type = '';
		$uploadfiles->ukuran = '';
		
	
		return $uploadfiles;
	}
   public function insert_file($filename, $title,$type, $ukuran)
   {
      $data = array(
         'filename'     => $filename,
         'title'        => $title,
      		'type'        => $type,
      		'ukuran'        => $ukuran
      );
      $this->db->insert('files', $data);
      return $this->db->insert_id();
   }

   public function get_files()
{
   return $this->db->select()
         ->from('files')
         ->get()
         ->result();
}

public function delete_file($file_id)
{
   $file = $this->get_file($file_id);
   if (!$this->db->where('id', $file_id)->delete('files'))
   {
      return FALSE;
   }
   unlink('./files/' . $file->filename);  
   return TRUE;
}
 
public function get_file($file_id)
{
   return $this->db->select()
         ->from('files')
         ->where('id', $file_id)
         ->get()
         ->row();
}
 
}
?>